#include "FlowSimTypes.h"

#include "FlowSimShaders.h"
#include "FlowSimulation.h"
#include "Serialization/CustomVersion.h"
#include "UObject/PropertyTag.h"

namespace
{
	/** Versions of UFlowSimConfig's saved data. An asset saved before
	 *  UFlowSimConfig::MeaningVersion loads its values under the current
	 *  meanings, unconverted. */
	struct FFlowSimConfigVersion
	{
		enum Type : int32
		{
			/** The hurricane traits as ranges; a saved scalar loads as Min = Max. */
			TraitRanges = 12,

			/** PITFALL: never lower this number. The engine refuses a package
			 *  saved at a version above Latest. */
			Current = TraitRanges,

			Latest = Current
		};

		static const FGuid Guid;
	};

	const FGuid FFlowSimConfigVersion::Guid(0x6A1F3C52, 0x9B4E4D17, 0xA2C85E31, 0x7D90B4F6);

	FCustomVersionRegistration GRegisterFlowSimConfigVersion(
		FFlowSimConfigVersion::Guid, FFlowSimConfigVersion::Latest, TEXT("FlowSimConfig"));

	static_assert(FlowSimShader::MaxStormCells == 32, "MaxStormCells' ClampMax in FlowSimTypes.h names the slot count.");
	static_assert(UFlowSimConfig::MeaningVersion <= FFlowSimConfigVersion::Current, "MeaningVersion is a saved version.");

	float JetPeak(const UFlowSimConfig& Config)
	{
		return FMath::Max(FlowSimProfile::PeakWind([&Config](float Mu) { return FlowSimProfile::JetRate(Config, Mu, 1.0f, Config.EquatorialBoost); }), 1e-3f);
	}

	float ShapePeak(const UFlowSimConfig& Config)
	{
		return FMath::Max(FlowSimProfile::PeakWind([&Config](float Mu) { return FlowSimProfile::ThermalShape(Config, Mu); }), 1e-3f);
	}

	/** SimRowStiffness at the equator: the Laplacian's diagonal there, the
	 *  eigenvalue of the grid-scale mode that divergence damping's fraction
	 *  refers to. */
	float EquatorStiffness(const UFlowSimConfig& Config)
	{
		const float DLon = 2.0f * UE_PI / FlowSimShader::GridLongitude(Config.GridResolution);
		const float DMu = 2.0f / FlowSimShader::GridLatitude(Config.GridResolution);

		return 2.0f / (DLon * DLon) + 2.0f / (DMu * DMu);
	}

	/** Most of the grid-scale divergence one step may remove. */
	constexpr float MaxDampingFraction = FlowSimShader::DampingMax;
}

// ---------------------------------------------------------------------------
// Profiles
// ---------------------------------------------------------------------------

float FlowSimProfile::JetRate(const UFlowSimConfig& Config, float Mu, float Strength, float Boost)
{
	if (Config.ZonalProfile == EFlowZonalProfile::ThreeCell)
	{
		const float Scale = JetLatitudeScale(Config);

		if (Scale != 1.0f)
		{
			Mu = FMath::Sin(FMath::Clamp(FMath::Asin(FMath::Clamp(Mu, -1.0f, 1.0f)) * Scale, -0.5f * UE_PI, 0.5f * UE_PI));
		}

		const FVector4f Form = JetForm(Config);
		const float A = FMath::Abs(Mu);
		const float Jet = (A - 0.71f) / 0.17f;
		const float Trades = Mu / 0.33f;
		const float Polar = (A - 0.97f) / 0.09f;

		return Strength * (FMath::Exp(-Jet * Jet) - Form.Z * FMath::Exp(-Trades * Trades) - Form.W * FMath::Exp(-Polar * Polar));
	}

	const FVector4f Shape = JetShape(Config);
	const FVector4f Form = JetForm(Config);
	const float K = Config.BandCount * UE_PI;
	const float Raw = (FMath::Cos(K * Mu) + Shape.X * FMath::Cos(K * Shape.Y * Mu) + Config.Asymmetry * FMath::Sin(K * 0.6f * Mu))
		* Shape.Z - Config.WidthBias;

	float Saturated = Raw;
	const float Abs = FMath::Abs(Raw);

	if (Abs > Form.X)
	{
		const float U = FMath::Clamp((Abs - Form.X) / Form.Y, 0.0f, 1.0f);
		const float U4 = U * U * U * U;
		Saturated = FMath::Sign(Raw) * (Form.X + Form.Y * (U - (U4 * U * U - 3.0f * U4 * U + 2.5f * U4)));
	}

	return Strength * (Saturated + Boost * FMath::Exp(-Mu * Mu * Shape.W));
}

FVector4f FlowSimProfile::JetShape(const UFlowSimConfig& Config)
{
	const float Irregularity = FMath::Max(Config.JetIrregularity, 0.0f);
	const float Half = FMath::Sin(FMath::DegreesToRadians(FMath::Clamp(Config.EquatorialJetWidth, 0.5f, 89.0f)));

	// The boost is exp(-W S^2), half at S = sin(EquatorialJetWidth).
	constexpr float Ln2 = 0.693147181f;

	return FVector4f(Irregularity, Config.JetHarmonic, 1.0f / (1.0f + Irregularity), Ln2 / (Half * Half));
}

FVector4f FlowSimProfile::JetForm(const UFlowSimConfig& Config)
{
	const float Flatness = FMath::Clamp(Config.JetFlatness, 0.05f, 0.95f);

	// The quintic tops out at Knee + Width / 2, which is 1 for any flatness.
	return FVector4f(1.0f - Flatness, 2.0f * Flatness, Config.TradeWindStrength, Config.PolarEasterlyStrength);
}

float FlowSimProfile::JetLatitudeScale(const UFlowSimConfig& Config)
{
	return 45.0f / FMath::Clamp(Config.JetLatitude, 15.0f, 75.0f);
}

float FlowSimProfile::PeakWind(TFunctionRef<float(float)> Rate)
{
	constexpr int32 Samples = 512;

	float Peak = 0.0f;

	for (int32 i = 0; i < Samples; ++i)
	{
		const float Mu = -1.0f + (i + 0.5f) * (2.0f / Samples);

		Peak = FMath::Max(Peak, FMath::Abs(Rate(Mu)) * FMath::Sqrt(1.0f - Mu * Mu));
	}

	return Peak;
}

float FlowSimProfile::ThermalShape(const UFlowSimConfig& Config, float Mu)
{
	if (Config.ThermalShape == EFlowThermalShape::FollowJets)
	{
		return JetRate(Config, Mu, 1.0f, Config.EquatorialBoost);
	}

	const float Offset = (FMath::Abs(FMath::Asin(FMath::Clamp(Mu, -1.0f, 1.0f))) - FMath::DegreesToRadians(Config.BaroclinicLatitude))
		/ FMath::Max(FMath::DegreesToRadians(Config.BaroclinicWidth), 1e-3f);

	return FMath::Exp(-Offset * Offset);
}

float FlowSimProfile::WaveSpeed(const UFlowSimConfig& Config)
{
	return FMath::Max(Config.DeformationRadius * Config.GetPlanetaryVorticity() * 0.70710678f, 1e-3f);
}

// ---------------------------------------------------------------------------
// Speed root
// ---------------------------------------------------------------------------

float UFlowSimConfig::GetSpeedRoot() const
{
	return FMath::Max(SpeedRoot, 0.1f) * FlowSimProfile::WaveSpeed(*this);
}

float UFlowSimConfig::GetNoiseDriftRate() const
{
	return NoiseDriftSpeed * GetSpeedRoot();
}

// The one floor: the sim's clock, its per-step reset test and the renderer's
// crossfade all read this value, so they reset together.
float UFlowSimConfig::GetNoiseResetTime() const
{
	return FMath::Max(NoiseResetTurnovers, 2.0f * FlowSimStep::SpinUp) * GetTurnover();
}

float UFlowSimConfig::GetTurnover() const
{
	return FMath::Max(DeformationRadius, 0.01f) / GetSpeedRoot();
}

// ---------------------------------------------------------------------------
// Grid damping
// ---------------------------------------------------------------------------

float UFlowSimConfig::GetImplicitWeight(float Step) const
{
	const float Authored = FlowSimNumerics::ImplicitWeight;

	return (FMath::Clamp(LayerCount, 1, 8) > 1 && Step > FlowSimStep::StackLargeStep * GetTurnover())
		? FMath::Max(Authored, FlowSimStep::StackWeight)
		: Authored;
}

float UFlowSimConfig::GetImplicitDampingRate(float Step) const
{
	if (Step <= 0.0f)
	{
		return 0.0f;
	}

	// Per step the off-centred scheme scales a gravity wave by |g|, with
	// |g|^2 = (1 + (1 - a)^2 A) / (1 + a^2 A) and A = (c dt)^2 k^2.
	const float C = FlowSimProfile::WaveSpeed(*this);
	const float A = C * C * Step * Step * EquatorStiffness(*this);
	const float Alpha = GetImplicitWeight(Step);

	return FMath::Loge((1.0f + Alpha * Alpha * A) / (1.0f + (1.0f - Alpha) * (1.0f - Alpha) * A)) / (2.0f * Step);
}

float UFlowSimConfig::GetDivergenceDamping(float Step) const
{
	const float Rate = FMath::Max(FMath::Max(GridDamping, 0.0f) / GetTurnover() - GetImplicitDampingRate(Step), 0.0f);

	return FMath::Min(1.0f - FMath::Exp(-Rate * FMath::Max(Step, 0.0f)), MaxDampingFraction);
}

FFlowSimScales UFlowSimConfig::ResolveScales() const
{
	FFlowSimScales S;

	S.WaveSpeed = FlowSimProfile::WaveSpeed(*this);
	S.Root = GetSpeedRoot();
	S.Turnover = GetTurnover();

	S.JetStrength = JetSpeed * S.Root / JetPeak(*this);
	S.ThermalShear = ShearSpeed * S.Root / ShapePeak(*this);

	S.EddySpeed = FMath::Max(EddySpeed, 0.0f) * S.Root;
	const FFlowSimRange Wind = StormCellWind.Clamped(0.0f, MAX_flt);
	S.CellWindRange = FVector2f(Wind.Min, Wind.Max) * S.Root;
	S.CellWind = Wind.Mid() * S.Root;
	S.CellDrift = FMath::Max(StormCellDriftSpeed, 0.0f) * S.Root;
	S.GenesisShear = FMath::Max(GenesisShearRatio * FMath::Max(FMath::Abs(ShearSpeed), 0.1f) * S.Root, 0.01f);

	S.WindEvaporation = FMath::Max(WindEvaporationGain, 0.0f) / S.Root;

	const float PerTurnover = 1.0f / S.Turnover;

	S.NudgeRate = NudgeRate * PerTurnover;
	S.DragRate = DragRate * PerTurnover;
	S.ThermalRelaxation = FMath::Max(ThermalRelaxation, 0.0f) * PerTurnover;
	S.LayerCoupling = LayerCoupling * PerTurnover;
	S.SurfaceEvaporation = FMath::Max(SurfaceEvaporation, 0.0f) * PerTurnover;
	S.CondensationRate = FMath::Max(CondensationRate, 0.0f) * PerTurnover;
	S.EvaporationRate = FMath::Max(EvaporationRate, 0.0f) * PerTurnover;
	S.CellSpawnRate = FMath::Max(StormCellSpawnRate, 0.0f) * PerTurnover;
	S.CellGrowth = FMath::Max(StormCellGrowth, 0.0f) * PerTurnover;
	S.CellFollow = FMath::Max(StormCellFollow, 0.0f) * PerTurnover;
	S.CellCoreFollow = FMath::Max(StormCellCoreFollow, 0.0f) * PerTurnover;
	S.CellForcing = FMath::Max(StormCellForcing, 0.0f) * PerTurnover;

	S.CloudLifetime = FMath::Max(CloudLifetime * S.Turnover, 1e-3f);
	S.AscentSmoothing = FlowSimNumerics::AscentSmoothing * S.Turnover;
	S.StormLifetime = FMath::Max(StormLifetime * S.Turnover, 1e-3f);
	S.CellLifetimeRange = FVector2f(
		FMath::Max(StormCellLifetime.Min * S.Turnover, 0.01f),
		FMath::Max(FMath::Max(StormCellLifetime.Min, StormCellLifetime.Max) * S.Turnover, 0.01f));
	S.CellLifetime = 0.5f * (S.CellLifetimeRange.X + S.CellLifetimeRange.Y);
	S.ForcingLifetime = FMath::Max(ForcingLifetime * S.Turnover, 0.01f);

	const float DR = FMath::Max(DeformationRadius, 0.01f);

	const FFlowSimRange Radius = FFlowSimRange(StormCellRadius.Min * DR, StormCellRadius.Max * DR)
		.Clamped(FMath::DegreesToRadians(0.5f), FMath::DegreesToRadians(45.0f));
	S.CellRadiusRange = FVector2f(Radius.Min, Radius.Max);
	S.CellRadius = Radius.Mid();
	S.ForcingFrequency = ForcingFrequency / DR;

	return S;
}

uint32 UFlowSimConfig::GetSeedSalt() const
{
	if (Seed == 0)
	{
		return 0u;
	}

	// A full-avalanche mix, so neighbouring seeds share no key bits.
	uint32 H = (uint32)Seed;
	H ^= H >> 16;
	H *= 0x7FEB352Du;
	H ^= H >> 15;
	H *= 0x846CA68Bu;
	H ^= H >> 16;

	return H ? H : 1u;
}

// ---------------------------------------------------------------------------
// Loading
// ---------------------------------------------------------------------------

bool FFlowSimRange::SerializeFromMismatchedTag(const FPropertyTag& Tag, FStructuredArchive::FSlot Slot)
{
	if (Tag.Type == NAME_FloatProperty)
	{
		float Value = 0.0f;
		Slot << Value;
		Min = Max = Value;
		return true;
	}

	if (Tag.Type == NAME_DoubleProperty)
	{
		double Value = 0.0;
		Slot << Value;
		Min = Max = (float)Value;
		return true;
	}

	return false;
}

void UFlowSimConfig::Serialize(FArchive& Ar)
{
	Ar.UsingCustomVersion(FFlowSimConfigVersion::Guid);

	Super::Serialize(Ar);
}

void UFlowSimConfig::PostLoad()
{
	Super::PostLoad();

	if (HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
	{
		return;
	}

	const int32 Version = GetLinkerCustomVersion(FFlowSimConfigVersion::Guid);

	if (Version < MeaningVersion)
	{
		UE_LOG(LogFlowSim, Warning,
			TEXT("'%s' is config version %d, older than %d: its values apply under the current meanings, unconverted. ")
			TEXT("Load a preset with CloudAtmosphere.LoadParams and save the asset."),
			*GetName(), Version, MeaningVersion);
	}
}
