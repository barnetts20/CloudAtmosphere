// THE TRANSFORM IS THE INTERFACE.
//
//   Actor Location  -> planet centre / atmosphere centre
//   Actor Scale max -> planet radius
//   Actor Rotation  -> light direction, and the directional light's rotation
//
// When owned by APlanetActor the scale is set externally to
// max(OceanRadius, PlanetRadius), the visible surface floor.
//
// THREE MODELS SHARE ONE FIELD AND ONE MARCH, run as compute passes with a
// temporal resolve (FAtmosphereViewExtension), the sim as their weather map: a
// terrestrial slab over a surface, a gas giant's deep deck over a saturated
// core, or the terrestrial air alone. The two cloud models each have a
// parameter bundle and sim config (AtmosphereParams.h); air only uses the
// terrestrial ones. The nearest claiming planet drives the world's one sim;
// the others draw the field they kept (UFlowSimSubsystem).

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/PostProcessVolume.h"
#include "Engine/DirectionalLight.h"
#include "Components/DirectionalLightComponent.h"
#include "Engine/VolumeTexture.h"
#include "AtmosphereParams.h"
#include "AtmosphereTransmittance.h"
#include "AtmosphereShadowBake.h"
#include "AtmosphereWeather.h"
#include "PlanetAtmosphereActor.generated.h"

class UTexture2D;
class UTextureRenderTarget2D;
class UTextureRenderTarget2DArray;
class FAtmosphereViewExtension;
class UFlowSimConfig;
struct FAtmosphereMarchParams;
struct FTerrestrialShadowParams;

/** The clocks a planet's field is drawn at: the sim's while the planet drives
 *  it, the kept field's otherwise. SIM TIME, NOT WORLD TIME: the field is
 *  coherent against the sim's own clock, which pauses, steps by hand and
 *  restores from snapshots. Double; the field's clocks reduce from it before
 *  narrowing. */
struct FAtmosphereFieldClock
{
    /** Sim time of the field shown, which the noise's drift and phases follow. */
    double Time = 0.0;

    /** Sim time the planet's spin turns the field by. Runs on while the field
     *  is kept, so a kept field still turns with its planet. */
    double SpinTime = 0.0;

    /** The config the field was simulated under, whose noise clocks it reads. */
    TWeakObjectPtr<const UFlowSimConfig> Config;
};

/** Renders a volumetric atmosphere and cloud layer. A scene view extension runs
 *  the march, temporal resolve and composite as compute passes, fed every tick
 *  by UpdateAtmosphere with the active model's params, the shadow bake and the
 *  transmittance table. Owns a directional light synced from the actor's rotation
 *  and LightColor. When planet-owned, location and scale are locked. The details
 *  panel shows CloudAtmosphere first, its groups in declaration order:
 *  Atmosphere, Model, Pipeline, Advanced Graphics. The panel shows nothing
 *  else but the transform: the engine's actor groups are hidden, and the sun
 *  light, whose settings all derive from the actor, is not exposed. */
UCLASS(HideCategories = (Rendering, Replication, Collision, Actor, Input, Physics, Networking, LOD, HLOD, Cooking, WorldPartition, DataLayers, Events),
    meta = (PrioritizeCategories = "CloudAtmosphere"))
class CLOUDATMOSPHERE_API APlanetAtmosphereActor : public AActor
{
    GENERATED_BODY()

public:
    APlanetAtmosphereActor();

    // --- Atmosphere ---

    /** True when spawned and driven by APlanetActor. Location and scale become
     *  read-only; rotation remains editable (controls light direction). */
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "CloudAtmosphere|Atmosphere")
    bool bIsPlanetOwned = false;

    /** Which model renders: the terrestrial slab, the gas giant's deep deck,
     *  or the terrestrial air alone. A change rebakes the shadow map and
     *  restarts the view histories on the next tick. */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "CloudAtmosphere|Atmosphere")
    EPlanetAtmosphereType PlanetType = EPlanetAtmosphereType::GasGiant;

    /** Switches the model; takes effect as PlanetType's edit does. */
    UFUNCTION(BlueprintCallable, Category = "CloudAtmosphere")
    void SetPlanetType(EPlanetAtmosphereType InType);

    /** The star's colour. Only its hue is read: the brightest channel counts as
     *  1 and a negative one as 0. The march and the directional light both
     *  derive from LightProduct, so they cannot disagree about the star; light
     *  DIRECTION comes from the actor's rotation. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Atmosphere", meta = (HideAlphaChannel))
    FLinearColor LightColor = FLinearColor(1.0f, 0.95f, 0.9f, 1.0f);

    /** The star's brightness, on its brightest channel. Every ambient is a ratio
     *  of the light, so they follow it. Light is stored unexposed in half float,
     *  so the haze's forward lobe clips past about 1000 at MieG 0.95 and about
     *  40 at its 0.99 limit. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Atmosphere", meta = (ClampMin = "0.0", UIMax = "20.0"))
    float LightIntensity = 4.0f;

    /** LightColor's hue at LightIntensity: the light the march and the
     *  directional light take. Non-negative: negative radiance makes the
     *  temporal resolve's compression singular. */
    FLinearColor LightProduct() const
    {
        const FLinearColor Hue = LightColor.GetClamped(0.0f, MAX_flt);
        const float Peak = FMath::Max3(Hue.R, Hue.G, Hue.B);
        const float Scale = (Peak > 0.0f) ? FMath::Max(LightIntensity, 0.0f) / Peak : 0.0f;

        return FLinearColor(Hue.R * Scale, Hue.G * Scale, Hue.B * Scale, 1.0f);
    }

    /** Parks or wakes the passes, the light and the per-tick updates. THE ONLY
     *  OFF-SWITCH for the march: hiding the actor or stopping its tick leaves
     *  it drawing. Parking gives up the sim, keeping the field; waking rebakes
     *  every shadow level. */
    UFUNCTION(BlueprintCallable, Category = "CloudAtmosphere")
    void SetAtmosphereActive(bool bActive);

    UFUNCTION(BlueprintPure, Category = "CloudAtmosphere")
    bool IsAtmosphereActive() const { return bAtmosphereActive; }

    /** Aim the light and the march at the star: sets the actor's relative
     *  rotation, which is the light direction, toward StarWorldPos and runs the
     *  rotation-to-light sync. The cloud field keeps the planet's frame. Called
     *  each frame by the owning planet from IStarLit::SetStarWorldPosition. */
    UFUNCTION(BlueprintCallable, Category = "CloudAtmosphere")
    void OrientToStar(const FVector& StarWorldPos);

    /** The performance tier written to Advanced Graphics. Choosing one in the
     *  panel applies it; later edits there stay until the next choice. */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "CloudAtmosphere|Atmosphere")
    EAtmosphereGraphicsPreset GraphicsPreset = EAtmosphereGraphicsPreset::High;

    /** Writes GraphicsPreset's values to Advanced Graphics; the passes take
     *  them on the next tick, and a new ShadowResolution rebakes. */
    UFUNCTION(BlueprintCallable, Category = "CloudAtmosphere")
    void ApplyGraphicsPreset();

    /** Selects a preset and applies it, as from a settings menu. */
    UFUNCTION(BlueprintCallable, Category = "CloudAtmosphere")
    void SetGraphicsPreset(EAtmosphereGraphicsPreset InPreset);

    // --- Parameters ---
    //
    // ONE BUNDLE PER MODEL, each shown only while its model is active. A
    // group's default lives with its struct; the constructor sets the
    // terrestrial air, ambient, multiple scattering and surface shadows on the
    // CDO, which the gas giant copies.

    /** The terrestrial model's, which air only draws without its clouds. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Model", meta = (EditCondition = "PlanetType != EPlanetAtmosphereType::GasGiant", EditConditionHides))
    FAtmosphereModelParams Terrestrial;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Model", meta = (EditCondition = "PlanetType == EPlanetAtmosphereType::GasGiant", EditConditionHides))
    FAtmosphereModelParams GasGiant;

    /** A model's bundle, as a copy. */
    UFUNCTION(BlueprintPure, Category = "CloudAtmosphere")
    FAtmosphereModelParams GetModelParams(EPlanetAtmosphereType InModel) const;

    /** Replaces a model's bundle; the next tick pushes it and rebakes the
     *  shadows if the field changed. Which groups the model shows is kept. */
    UFUNCTION(BlueprintCallable, Category = "CloudAtmosphere")
    void SetModelParams(EPlanetAtmosphereType InModel, const FAtmosphereModelParams& InParams);

    /** A model's sim config to change at runtime. In a game world the first call
     *  replaces the slot's shared asset with a transient copy owned by this actor,
     *  which a running sim carries on under, so no other planet or asset sees the
     *  change. In an editor world it is the asset, so tuning saves. Null when the
     *  slot is empty. */
    UFUNCTION(BlueprintCallable, Category = "CloudAtmosphere")
    UFlowSimConfig* GetWritableSimConfig(EPlanetAtmosphereType InModel);

    // --- Pipeline: the assets and passes the actor drives. ---

    /** Tiling single-channel blue noise for the march: sRGB off, uncompressed
     *  grayscale, no mips, nearest filtering. Cleared, nothing draws. */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "CloudAtmosphere|Pipeline")
    TObjectPtr<UTexture2D> BlueNoise;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Pipeline")
    FAtmosphereSimulationParams Simulation;

    /** Stage A5: seconds between read-backs of the field's weather at the surface for the CPU
     *  (GetWeatherFeed), while something holds the feed (the ocean). 0: none. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Pipeline", meta = (ClampMin = "0.0", UIMax = "60.0"))
    float WeatherReadbackSeconds = 10.0f;

    /** Stage A11: seconds between read-backs of the sim's climate (GetClimateFeed), while this
     *  planet drives the sim. 0: none. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Pipeline", meta = (ClampMin = "0.0", UIMax = "60.0"))
    float ClimateReadbackSeconds = 10.0f;

    /** Stage A11: the latest climate map as a texture to look at (on the sim's grid: R
     *  precipitation, G humidity, B cloud cover, A warmth + 0.5), remade as each lands while
     *  r.CloudAtmosphere.ClimateView is 1. */
    UPROPERTY(Transient, VisibleInstanceOnly, BlueprintReadOnly, Category = "CloudAtmosphere|Pipeline")
    TObjectPtr<UTexture2D> ClimateView;

    // Advanced Graphics: the performance tier, shared by both models; tunes
    // apply it only on request. GraphicsPreset writes all of it but
    // ShadowTemporalSmoothing, which costs nothing. The cascade extents are
    // look, in each model's SurfaceShadow.

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Advanced Graphics|Raymarch", meta = (ShowOnlyInnerProperties))
    FAtmosphereRaymarchParams Raymarch;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Advanced Graphics|Sampling", meta = (ShowOnlyInnerProperties))
    FAtmosphereSamplingParams Sampling;

    /** The deck shadow bake in the light's frame: a cascade of slices, each
     *  covering a smaller radius, sized by ShadowResolution. */
    UPROPERTY(Transient, VisibleInstanceOnly, BlueprintReadOnly, Category = "CloudAtmosphere|Pipeline|Baked Lighting")
    TObjectPtr<UTextureRenderTarget2DArray> ShadowTarget;

    /** One texel: the coverage priority threshold the bake's coverage pass
     *  solves each frame, read by the bake and the march. */
    UPROPERTY(Transient, VisibleInstanceOnly, BlueprintReadOnly, Category = "CloudAtmosphere|Pipeline|Baked Lighting")
    TObjectPtr<UTextureRenderTarget2D> CoverageTarget;

    /** The flow atlas this planet draws: the sim's while it drives the sim,
     *  KeptFlow while another planet does. */
    UPROPERTY(Transient, VisibleInstanceOnly, BlueprintReadOnly, Category = "CloudAtmosphere|Pipeline")
    TObjectPtr<UTextureRenderTarget2DArray> FlowTarget;

    /** The field as this planet last drove it, copied when another planet took
     *  the sim; clear until it first drives it. */
    UPROPERTY(Transient, VisibleInstanceOnly, BlueprintReadOnly, Category = "CloudAtmosphere|Pipeline")
    TObjectPtr<UTextureRenderTarget2DArray> KeptFlow;

    /** The sim's debug view while this planet drives the sim and the config's
     *  bDebugView is on. */
    UPROPERTY(Transient, VisibleInstanceOnly, BlueprintReadOnly, Category = "CloudAtmosphere|Pipeline")
    TObjectPtr<UTextureRenderTarget2D> SimDebugView;

    /** Edge of every cascade slice, in texels. Bake time and memory scale with
     *  its square, 2 MB per slice at 512; lower softens rather than aliases. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Advanced Graphics|Shadows", meta = (ClampMin = "128", ClampMax = "4096"))
    int32 ShadowResolution = 1024;

    /** Seconds a rebaked cascade fades in from its reprojected previous bake:
     *  hides rebake steps, and the shadow trails the clouds by about this. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CloudAtmosphere|Advanced Graphics|Shadows", meta = (ClampMin = "0.0", UIMax = "1.0"))
    float ShadowTemporalSmoothing = 0.1f;

    // --- The active model ---

    /** The sim config the active model bids with. */
    UFlowSimConfig* ActiveSimConfig() const;

    /** The clocks this frame's field is drawn at. */
    const FAtmosphereFieldClock& GetFieldClock() const
    {
        return FieldClock;
    }

    const FAtmosphereModelParams& ActiveModel() const
    {
        return ModelOf(PlanetType);
    }

    /** The model draws clouds, and so runs the sim and the shadow bake. */
    bool HasClouds() const { return PlanetType != EPlanetAtmosphereType::AirOnly; }

    /** The clouds are the gas giant's deep deck rather than the slab. */
    bool IsDeepDeck() const { return PlanetType == EPlanetAtmosphereType::GasGiant; }

    /** Above zero: the atmosphere's thickness divides every height. */
    float ActiveHeightScale() const
    {
        return FMath::Max(ActiveModel().Planet.HeightScale, 1e-4f);
    }

    /** The noise volumes, which both models bind under the same names. */
    UVolumeTexture* ActiveStructureVolume() const
    {
        return ActiveModel().StructureLayer.Volume.Get();
    }

    UVolumeTexture* ActiveDetailVolume() const
    {
        return ActiveModel().DetailLayer.Volume.Get();
    }

    // --- Lifecycle ---

    virtual void OnConstruction(const FTransform& Transform) override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
    virtual void Destroyed() override;
    virtual void BeginDestroy() override;
    virtual bool ShouldTickIfViewportsOnly() const override { return true; }
    virtual void Tick(float DeltaTime) override;

    // --- Editor Property & Transform Locking ---

#if WITH_EDITOR
    virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
    virtual void PostEditMove(bool bFinished) override;
    virtual void EditorApplyTranslation(const FVector& DeltaTranslation, bool bAltDown, bool bShiftDown, bool bCtrlDown) override;
    virtual void EditorApplyScale(const FVector& DeltaScale, const FVector* PivotLocation, bool bAltDown, bool bShiftDown, bool bCtrlDown) override;
#endif

    /** Called by PlanetActor after spawn and attach. Sets bIsPlanetOwned, binds
     *  the transform guard and runs Initialize, with InScale applied first.
     *  Skips the deferred OnConstruction path. InAttachParent is unread: the
     *  caller attaches. */
    UFUNCTION(BlueprintCallable, Category = "CloudAtmosphere")
    void InitializeFromPlanet(USceneComponent* InAttachParent,
        FVector InScale = FVector::ZeroVector);

    /** Stage A2: the march's view extension, for a renderer that lights its
     *  own sun with it (AddSurfaceSunPass_RenderThread, SetSelfLitMask_RenderThread).
     *  Null until the first frame the march runs; released and made again
     *  when the atmosphere is turned off and on, so hold it weakly and ask
     *  each frame. Game thread. */
    TWeakPtr<FAtmosphereViewExtension, ESPMode::ThreadSafe> GetViewExtension() const { return ViewExtension; }

    /** Stage A2: the atmosphere's sun light, the star's light above the air.
     *  Game thread. */
    UDirectionalLightComponent* GetSunLight() const { return SunLightComponent; }

    /** Stage A5: the field's weather at the surface on the CPU (AtmosphereWeather.h), read back
     *  every WeatherReadbackSeconds while anything but the actor holds the feed. Any thread reads
     *  it; empty until the first read-back lands, and on air alone. */
    TSharedRef<FAtmosphereWeatherFeed, ESPMode::ThreadSafe> GetWeatherFeed() const { return WeatherFeed; }

    /** Stage A9: the planet's surface under the weather sim (UFlowSimConfig's Planet|Surface):
     *  Width x Height cells on the sim's own layout (longitude x sin(latitude), planet-local
     *  with Z the spin axis and longitude 0 on +X; row 0 the south; cell (i, j) centred at
     *  longitude 2 pi (i + 0.5) / Width, sin(latitude) -1 + 2 (j + 0.5) / Height), each
     *  (elevation 0 sea level .. 1 the highest, land 0 .. 1). The terrestrial model's sim takes
     *  it on this actor's own config (a generated one, or a game world's copy), live, without a
     *  restart; an empty map clears it (all sea, as before). The sim is in the planet's frame:
     *  the terrestrial model doesn't spin it. Game thread. */
    void SetSurfaceMap(int32 Width, int32 Height, TConstArrayView<FVector2f> Cells);

    /** Stage A9: the surface map SetSurfaceMap made (null: none). */
    UTexture2D* GetSurfaceMap() const { return SurfaceMap; }

    /** Stage A11: the sim's climate (AtmosphereWeather.h FAtmosphereClimateMap), read back every
     *  ClimateReadbackSeconds while this planet drives the sim; the last one kept while another
     *  does. Any thread reads it; empty until the first lands. */
    TSharedRef<FAtmosphereClimateFeed, ESPMode::ThreadSafe> GetClimateFeed() const { return ClimateFeed; }

    /** Stage T5b: restarts the sim from its start (the seed's state or InitialState: a new spin-up
     *  and climate window, so a new climate snapshot) when this planet drives it; nothing else. A
     *  planet whose ground changed (a new surface map) calls it for a climate of the new ground. */
    UFUNCTION(BlueprintCallable, Category = "CloudAtmosphere")
    void RestartSimulation();

    /** Stage T5b: whether this planet drives the sim (its weather and climate are this planet's). */
    UFUNCTION(BlueprintPure, Category = "CloudAtmosphere")
    bool DrivesSimulation() const;

    /** Stage T5b: whether a climate snapshot can come from this planet's sim: it drives the sim,
     *  the sim steps (not paused), has (or will have at its next reset) a climate window, and the
     *  climate reads back (ClimateReadbackSeconds above 0). */
    bool CanProvideClimateSnapshot() const;

    /** R1 (ATM-1): whether this atmosphere bids for the sim at all (active, with clouds, claiming
     *  on, a sim config): a planet waiting for a climate snapshot from one that doesn't takes its
     *  provisional model at once instead of waiting out its timeout. */
    bool BidsForSimulation() const;

protected:
    /** R1 (ATM-3): called at the top of Initialize, before the first bid for the sim: a subclass
     *  that generates its sim config (the seeded atmosphere) does so here, so the first bid is
     *  made with it and the sim isn't started once on the shared default config and restarted
     *  a frame later. */
    virtual void PrepareForInitialize() {}

private:
    /** Root component; carries the planet radius as scale. */
    UPROPERTY()
    TObjectPtr<USceneComponent> AtmosphereRoot;

    /** Synced from the actor's rotation and LightColor, in absolute rotation
     *  and scale. A component, so a duplicate or deletion takes its own. Not
     *  in the panel: exposed, its settings would show on the actor. */
    UPROPERTY()
    TObjectPtr<UDirectionalLightComponent> SunLightComponent;

    /** Legacy child actors a saved level can still hold, destroyed on Initialize. */
    UPROPERTY()
    TObjectPtr<APostProcessVolume> PostProcessVolume_DEPRECATED = nullptr;

    UPROPERTY()
    TObjectPtr<ADirectionalLight> SunLight_DEPRECATED = nullptr;

    /** Stage A9: the planet's surface for the sim (SetSurfaceMap). */
    UPROPERTY(Transient)
    TObjectPtr<UTexture2D> SurfaceMap = nullptr;

    /** Air transmittance table, created on first use. */
    UPROPERTY(Transient, VisibleInstanceOnly, Category = "CloudAtmosphere|Pipeline|Baked Lighting")
    TObjectPtr<UTextureRenderTarget2D> TransmittanceTable = nullptr;

    /** Inputs of the last enqueued bake; reset when the table is recreated. */
    FAtmosphereTransmittanceParams TransmittanceBaked;

    /** A model's bundle and sim config slot; air only shares the terrestrial's. */
    const FAtmosphereModelParams& ModelOf(EPlanetAtmosphereType InModel) const;
    FAtmosphereModelParams& ModelOf(EPlanetAtmosphereType InModel);
    TObjectPtr<UFlowSimConfig>& SimConfigSlot(EPlanetAtmosphereType InModel);

    /** Sets each bundle's transient flags for which groups the panel shows. */
    void SyncModelFlags();

    /** Gives up the sim claim, keeping the field, and unprimes the shadow map.
     *  The shadow and coverage targets are kept for the clouds' return. */
    void ReleaseCloudResources();

    /** The model the shadow map was last baked for; a change rebakes every level. */
    EPlanetAtmosphereType ShadowType = EPlanetAtmosphereType::Terrestrial;

    bool bInitialized = false;

    /** Initialize runs on the next Tick outside a preview world. True from
     *  construction, so a loaded actor initialises without OnConstruction. */
    bool bPendingInitialize = true;

    /** False while parked by SetAtmosphereActive. */
    bool bAtmosphereActive = true;

    /** True while this actor bids for the sim, so it releases it when it goes. */
    bool bClaimedSimulation = false;

    FAtmosphereFieldClock FieldClock;

    /** The clock KeptFlow was copied at, and the world time then: what a kept
     *  field is drawn at. */
    FAtmosphereFieldClock KeptClock;
    double KeptAt = 0.0;

    /** The frame the last shadow bake was requested on: one request per frame
     *  however many paths push parameters. */
    uint64 ShadowBakeFrame = MAX_uint64;

    /** The root's scale relative to the planet, as the planet set it: what the
     *  transform guard holds. */
    FVector PlanetDrivenScale = FVector::OneVector;

    /** Bound to RootComponent->TransformUpdated when planet-owned. Snaps location
     *  and scale back to planet-driven values, leaving rotation alone. */
    void OnTransformUpdated(USceneComponent* Component, EUpdateTransformFlags Flags, ETeleportType Teleport);

    /** Destroys legacy objects, pushes every parameter and syncs the light. */
    void Initialize();

    /** Destroys the legacy child actors and components a saved level can hold. */
    void DestroyLegacyChildActors();

    /** Withdraws this actor's bid, stopping the sim if it drives it;
     *  bKeepField keeps its field first. */
    void ReleaseSimulation(bool bKeepField);

    /** Bids for the sim with the active model's config, and picks what this
     *  frame draws: the sim's flow and clock while this planet drives it, the
     *  kept ones otherwise. */
    void ClaimSimulation(const FVector& PlanetCenter, float PlanetRadius);

    /** Runs the march, its temporal resolve and the composite as compute
     *  passes for this world's views. Created on first use, released on the
     *  render thread. */
    TSharedPtr<FAtmosphereViewExtension, ESPMode::ThreadSafe> ViewExtension;

    /** Stage A5: the weather's feed, its render-thread read-back (made on first use, released
     *  with the view extension), and when it last ran (platform seconds). */
    TSharedRef<FAtmosphereWeatherFeed, ESPMode::ThreadSafe> WeatherFeed = MakeShared<FAtmosphereWeatherFeed, ESPMode::ThreadSafe>();
    TSharedPtr<FAtmosphereWeatherReadback, ESPMode::ThreadSafe> WeatherReadback;
    double WeatherReadbackTime = -1.0e9;

    /** Stage A11: the climate's feed and read-back, when it last ran, and the serial the view
     *  texture shows. */
    TSharedRef<FAtmosphereClimateFeed, ESPMode::ThreadSafe> ClimateFeed = MakeShared<FAtmosphereClimateFeed, ESPMode::ThreadSafe>();
    TSharedPtr<FAtmosphereClimateReadback, ESPMode::ThreadSafe> ClimateReadback;
    double ClimateReadbackTime = -1.0e9;
    uint64 ClimateViewSerial = 0;
    /** Stage T5b: the sim's climate window (UFlowSimSubsystem::GetClimateWindowSerial) whose
     *  snapshot was read back (0: none yet). */
    uint32 ClimateSnapshotSerialRead = 0;

    /** Stage A11: reads the climate back when due (this planet driving the sim), publishes what has
     *  landed, and remakes the view texture from a new map. */
    void UpdateClimateReadback();

    /** Reads the weather back when due, and publishes what has landed. */
    void UpdateWeatherReadback(const FAtmosphereMarchParams& March);

    /** Suppress the per-tick repeat of the missing blue noise and structure
     *  volume warnings; each clears once its asset is set. */
    bool bWarnedBlueNoise = false;
    bool bWarnedStructureVolume = false;

    /** Hands the view extension this frame's march while its resources are
     *  set, and enables it to match. */
    void UpdateComputeMarch(float PlanetRadius, const FVector& PlanetCenter, const FVector& LightDir);

    /** The active model's march inputs, from the packers the shadow bake
     *  shares. False when a resource the march needs is missing. */
    bool FillMarchParams(FAtmosphereMarchParams& Out, float PlanetRadius,
        const FVector& PlanetCenter, const FVector& LightDir);

    /** Disables the view extension and drops it on the render thread, with its
     *  histories. */
    void ReleaseViewExtension();

    /** The shadow bake, the transmittance table and the march, for the active
     *  model. Called every tick. */
    void UpdateAtmosphere();

    /** Queues this frame's shadow bake with the sim subsystem, on the field
     *  packer and shader functions the march shares. */
    void RequestShadowBake(float PlanetRadius, const FVector& PlanetCenter, const FVector& LightDir);

    /** A bake request's map, frame, light, camera, history and volumes; false
     *  when unusable. CommitShadowBake records it once taken. */
    bool FillShadowRequest(FTerrestrialShadowParams& Params, float PlanetRadius,
        const FVector& PlanetCenter, const FVector& LightDir);

    /** Records an accepted bake: the cameras the march reads the fine levels
     *  against, and the light and time the next bake reprojects from. */
    void CommitShadowBake(uint32 LevelMask, const FVector3f& LightDir, const FVector3f& CameraLocal);

    /** Creates the shadow target if absent and forces it to RGBA16F with UAV
     *  support at ShadowResolution, cleared to the no-deck sentinel,
     *  reinitialising only on a mismatch. */
    void PrepareShadowTarget();

    /** Creates the one-texel R32F coverage target if absent, cleared above any
     *  priority. */
    void PrepareCoverageTarget();

    /** The next cascade in the bake rotation, and the camera each level was
     *  last baked around -- what the march reads that level against. */
    int32 ShadowLevelCursor = 0;
    FVector3f ShadowBakedCamera[AtmoShadowBake::CascadeCount];

    /** The light each level was last baked under, and when, in world
     *  seconds: what the next bake of that level reprojects and weights its
     *  history by. */
    FVector3f ShadowBakedLight[AtmoShadowBake::CascadeCount];
    double ShadowBakeTime[AtmoShadowBake::CascadeCount] = {};

    /** False until every level is baked into the current target; cleared on a
     *  new target, model or field, or a wake, so the next request bakes all. */
    bool bShadowPrimed = false;

    /** The field the map was last requested for, as MakeShadowFieldKey. */
    uint32 ShadowFieldKey = 0;

    /** Creates the transmittance table if needed, and rebakes it when its
     *  inputs or its resource change. */
    void UpdateTransmittanceTable(float PlanetRadius);

    /** Creates the table if absent and forces its fixed size, float format,
     *  clamp addressing and UAV support. */
    void PrepareTransmittanceTable();

    /** Warns once when the active model has no sim config. */
    bool bWarnedSimConfig = false;

    /** Syncs the directional light's rotation, colour and intensity from the
     *  actor's rotation and the LightColor property. */
    void UpdateLightFromRotation();

    /** The frame the cloud field is defined in: the planet's, which the
     *  atmosphere is attached to, or the world's when it stands alone. The
     *  actor's own rotation is the light direction and never turns the field. */
    FQuat GetFieldFrame() const;
};
