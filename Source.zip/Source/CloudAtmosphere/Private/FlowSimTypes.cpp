#include "FlowSimTypes.h"

#include "FlowSimShaders.h"
#include "FlowSimulation.h"
#include "Serialization/CustomVersion.h"

namespace
{
	/** Versions of UFlowSimConfig's saved data. An asset saved at an older
	 *  version loads its values under the current meanings, unconverted. */
	struct FFlowSimConfigVersion
	{
		enum Type : int32
		{
			/** PITFALL: never lower this number. The engine refuses a package
			 *  saved at a version above Latest. */
			Current = 7,

			Latest = Current
		};

		static const FGuid Guid;
	};

	const FGuid FFlowSimConfigVersion::Guid(0x6A1F3C52, 0x9B4E4D17, 0xA2C85E31, 0x7D90B4F6);

	FCustomVersionRegistration GRegisterFlowSimConfigVersion(
		FFlowSimConfigVersion::Guid, FFlowSimConfigVersion::Latest, TEXT("FlowSimConfig"));

	/** Largest |rate(mu) cos(latitude)| over the sphere: the peak eastward wind
	 *  of an angular-rate profile, sampled at row centres in mu. */
	template<typename TRate>
	float PeakWind(TRate&& Rate)
	{
		constexpr int32 Samples = 512;

		float Peak = 0.0f;

		for (int32 i = 0; i < Samples; ++i)
		{
			const float Mu = -1.0f + (i + 0.5f) * (2.0f / Samples);

			Peak = FMath::Max(Peak, FMath::Abs(Rate(Mu)) * FMath::Sqrt(1.0f - Mu * Mu));
		}

		return FMath::Max(Peak, 1e-3f);
	}

	float JetPeak(const UFlowSimConfig& Config)
	{
		return PeakWind([&Config](float Mu) { return FlowSimProfile::JetRate(Config, Mu, 1.0f, Config.EquatorialBoost); });
	}

	float ShapePeak(const UFlowSimConfig& Config)
	{
		return PeakWind([&Config](float Mu) { return FlowSimProfile::ThermalShape(Config, Mu); });
	}

	/** SimRowStiffness at the equator: the Laplacian's diagonal there, the
	 *  eigenvalue of the grid-scale mode that divergence damping's fraction
	 *  refers to. */
	float EquatorStiffness(const UFlowSimConfig& Config)
	{
		const float DLon = 2.0f * UE_PI / FlowSimShader::GridLongitude(Config.GridResolution);
		const float DMu = 2.0f / FlowSimShader::GridLatitude(Config.GridResolution);

		return 2.0f / (DLon * DLon) + 2.0f / (DMu * DMu);
	}

	/** Most of the grid-scale divergence one step may remove: SIM_DAMPING_MAX. */
	constexpr float MaxDampingFraction = 0.45f;
}

// ---------------------------------------------------------------------------
// Profiles
// ---------------------------------------------------------------------------

float FlowSimProfile::JetRate(const UFlowSimConfig& Config, float Mu, float Strength, float Boost)
{
	if (Config.ZonalProfile == EFlowZonalProfile::ThreeCell)
	{
		const float Scale = JetLatitudeScale(Config);

		if (Scale != 1.0f)
		{
			Mu = FMath::Sin(FMath::Clamp(FMath::Asin(FMath::Clamp(Mu, -1.0f, 1.0f)) * Scale, -0.5f * UE_PI, 0.5f * UE_PI));
		}

		const float A = FMath::Abs(Mu);
		const float Jet = (A - 0.71f) / 0.17f;
		const float Trades = Mu / 0.33f;
		const float Polar = (A - 0.97f) / 0.09f;

		return Strength * (FMath::Exp(-Jet * Jet) - 0.35f * FMath::Exp(-Trades * Trades) - 0.5f * FMath::Exp(-Polar * Polar));
	}

	const float K = Config.BandCount * UE_PI;
	const float Raw = (FMath::Cos(K * Mu) + 0.45f * FMath::Cos(K * 1.7f * Mu) + Config.Asymmetry * FMath::Sin(K * 0.6f * Mu))
		* 0.6897f - Config.WidthBias;

	float Saturated = Raw;
	const float Abs = FMath::Abs(Raw);

	if (Abs > 0.5f)
	{
		const float U = FMath::Clamp(Abs - 0.5f, 0.0f, 1.0f);
		const float U4 = U * U * U * U;
		Saturated = FMath::Sign(Raw) * (0.5f + U - (U4 * U * U - 3.0f * U4 * U + 2.5f * U4));
	}

	return Strength * (Saturated + Boost * FMath::Exp(-Mu * Mu * 12.0f));
}

float FlowSimProfile::JetLatitudeScale(const UFlowSimConfig& Config)
{
	return 45.0f / FMath::Clamp(Config.JetLatitude, 15.0f, 75.0f);
}

float FlowSimProfile::ThermalShape(const UFlowSimConfig& Config, float Mu)
{
	if (Config.ThermalShape == EFlowThermalShape::FollowJets)
	{
		return JetRate(Config, Mu, 1.0f, Config.EquatorialBoost);
	}

	const float Offset = (FMath::Abs(FMath::Asin(FMath::Clamp(Mu, -1.0f, 1.0f))) - FMath::DegreesToRadians(Config.BaroclinicLatitude))
		/ FMath::Max(FMath::DegreesToRadians(Config.BaroclinicWidth), 1e-3f);

	return FMath::Exp(-Offset * Offset);
}

float FlowSimProfile::WaveSpeed(const UFlowSimConfig& Config)
{
	return FMath::Max(Config.DeformationRadius * FMath::Max(Config.PlanetaryVorticity, 0.1f) * 0.70710678f, 1e-3f);
}

// ---------------------------------------------------------------------------
// Speed root
// ---------------------------------------------------------------------------

float UFlowSimConfig::GetSpeedRoot() const
{
	return FMath::Max(SpeedRoot, 0.1f) * FlowSimProfile::WaveSpeed(*this);
}

float UFlowSimConfig::GetNoiseDriftRate() const
{
	return NoiseDriftSpeed * GetSpeedRoot();
}

// The one floor: the sim's clock, its per-step reset test and the renderer's
// crossfade all read this value, so they reset together.
float UFlowSimConfig::GetNoiseResetTime() const
{
	return FMath::Max(FMath::Max(NoiseResetTurnovers, 0.05f) * GetTurnover(), 1e-3f);
}

float UFlowSimConfig::GetTurnover() const
{
	return FMath::Max(DeformationRadius, 0.01f) / GetSpeedRoot();
}

// ---------------------------------------------------------------------------
// Grid damping
// ---------------------------------------------------------------------------

float UFlowSimConfig::GetImplicitWeight(float Step) const
{
	const float Authored = FMath::Clamp(ImplicitWeight, 0.5f, 1.0f);

	return (FMath::Clamp(LayerCount, 1, 8) > 1 && Step > FlowSimStep::StackLargeStep)
		? FMath::Max(Authored, FlowSimStep::StackWeight)
		: Authored;
}

float UFlowSimConfig::GetImplicitDampingRate(float Step) const
{
	if (Step <= 0.0f)
	{
		return 0.0f;
	}

	// Per step the off-centred scheme scales a gravity wave by |g|, with
	// |g|^2 = (1 + (1 - a)^2 A) / (1 + a^2 A) and A = (c dt)^2 k^2.
	const float C = FlowSimProfile::WaveSpeed(*this);
	const float A = C * C * Step * Step * EquatorStiffness(*this);
	const float Alpha = GetImplicitWeight(Step);

	return FMath::Loge((1.0f + Alpha * Alpha * A) / (1.0f + (1.0f - Alpha) * (1.0f - Alpha) * A)) / (2.0f * Step);
}

float UFlowSimConfig::GetDivergenceDamping(float Step) const
{
	const float Rate = FMath::Max(FMath::Max(GridDamping, 0.0f) / GetTurnover() - GetImplicitDampingRate(Step), 0.0f);

	return FMath::Min(1.0f - FMath::Exp(-Rate * FMath::Max(Step, 0.0f)), MaxDampingFraction);
}

FFlowSimScales UFlowSimConfig::ResolveScales() const
{
	FFlowSimScales S;

	S.WaveSpeed = FlowSimProfile::WaveSpeed(*this);
	S.Root = GetSpeedRoot();
	S.Turnover = GetTurnover();

	S.JetStrength = JetSpeed * S.Root / JetPeak(*this);
	S.ThermalShear = ShearSpeed * S.Root / ShapePeak(*this);

	S.EddySpeed = FMath::Max(EddySpeed, 0.0f) * S.Root;
	S.CellWind = FMath::Max(StormCellSpeed, 0.0f) * S.Root;
	S.CellDrift = FMath::Max(StormCellDriftSpeed, 0.0f) * S.Root;
	S.GenesisShear = FMath::Max(GenesisShearRatio * FMath::Max(FMath::Abs(ShearSpeed), 0.1f) * S.Root, 0.01f);

	S.WindEvaporation = FMath::Max(WindEvaporationGain, 0.0f) / S.Root;

	const float PerTurnover = 1.0f / S.Turnover;

	S.NudgeRate = NudgeRate * PerTurnover;
	S.DragRate = DragRate * PerTurnover;
	S.ThermalRelaxation = FMath::Max(ThermalRelaxation, 0.0f) * PerTurnover;
	S.LayerCoupling = LayerCoupling * PerTurnover;
	S.SurfaceEvaporation = FMath::Max(SurfaceEvaporation, 0.0f) * PerTurnover;
	S.CondensationRate = FMath::Max(CondensationRate, 0.0f) * PerTurnover;
	S.EvaporationRate = FMath::Max(EvaporationRate, 0.0f) * PerTurnover;
	S.CellSpawnRate = FMath::Max(StormCellSpawnRate, 0.0f) * PerTurnover;
	S.CellGrowth = FMath::Max(StormCellGrowth, 0.0f) * PerTurnover;
	S.CellFollow = FMath::Max(StormCellFollow, 0.0f) * PerTurnover;
	S.CellCoreFollow = FMath::Max(StormCellCoreFollow, 0.0f) * PerTurnover;
	S.CellForcing = FMath::Max(StormCellForcing, 0.0f) * PerTurnover;

	S.CloudLifetime = FMath::Max(CloudLifetime * S.Turnover, 1e-3f);
	S.AscentSmoothing = FMath::Max(AscentSmoothing, 0.0f) * S.Turnover;
	S.StormLifetime = FMath::Max(StormLifetime * S.Turnover, 1e-3f);
	S.CellLifetime = FMath::Max(StormCellLifetime * S.Turnover, 0.01f);
	S.ForcingLifetime = FMath::Max(ForcingLifetime * S.Turnover, 0.01f);

	const float DR = FMath::Max(DeformationRadius, 0.01f);

	S.CellRadius = FMath::Clamp(StormCellRadius * DR, FMath::DegreesToRadians(0.5f), FMath::DegreesToRadians(45.0f));
	S.ForcingFrequency = ForcingFrequency / DR;

	return S;
}

// ---------------------------------------------------------------------------
// Loading
// ---------------------------------------------------------------------------

void UFlowSimConfig::Serialize(FArchive& Ar)
{
	Ar.UsingCustomVersion(FFlowSimConfigVersion::Guid);

	Super::Serialize(Ar);
}

void UFlowSimConfig::PostLoad()
{
	Super::PostLoad();

	if (HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
	{
		return;
	}

	const int32 Version = GetLinkerCustomVersion(FFlowSimConfigVersion::Guid);

	if (Version < FFlowSimConfigVersion::Current)
	{
		UE_LOG(LogFlowSim, Warning,
			TEXT("'%s' is config version %d, older than %d: its values apply under the current meanings, unconverted. ")
			TEXT("Load a preset with CloudAtmosphere.LoadParams and save the asset."),
			*GetName(), Version, (int32)FFlowSimConfigVersion::Current);
	}
}
