#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "FlowSnapshot.generated.h"

/** The profile a snapshot was captured under.
 *
 *  RECORDED RATHER THAN ASSUMED because a snapshot's eddies sit on the jets that
 *  existed when it was taken. Restored under a different profile they sit on
 *  jets that are not there, and the nudge re-registers the zonal mean over a few
 *  hundred steps -- quietly, looking wrong in the meantime. So it is reported at
 *  load instead. */
USTRUCT(BlueprintType)
struct FFlowSnapshotProvenance
{
	GENERATED_BODY()

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Provenance")
	float BandCount = 0.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Provenance")
	float JetStrength = 0.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Provenance")
	float EquatorialBoost = 0.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Provenance")
	float Asymmetry = 0.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Provenance")
	float WidthBias = 0.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Provenance")
	float PlanetaryVorticity = 0.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Provenance")
	float ThermalShear = 0.0f;

	/** True when this profile would draw the same jets at the same latitudes.
	 *  Only the parameters that place the jets are compared; the rest change how
	 *  the field evolves, not where its structure sits. */
	bool MatchesShape(const FFlowSnapshotProvenance& Other) const
	{
		const float Tol = 1e-3f;

		return FMath::IsNearlyEqual(BandCount, Other.BandCount, Tol)
			&& FMath::IsNearlyEqual(JetStrength, Other.JetStrength, Tol)
			&& FMath::IsNearlyEqual(EquatorialBoost, Other.EquatorialBoost, Tol)
			&& FMath::IsNearlyEqual(Asymmetry, Other.Asymmetry, Tol)
			&& FMath::IsNearlyEqual(WidthBias, Other.WidthBias, Tol)
			&& FMath::IsNearlyEqual(ThermalShear, Other.ThermalShear, Tol);
	}
};

/** A captured simulation state, as raw floats.
 *
 *  RAW FLOATS AND NOT A TEXTURE ASSET. A texture carries compression, sRGB and
 *  mip settings, and any one applied to a physical field destroys it in a way
 *  that presents as the sim misbehaving. A float array round-trips exactly.
 *
 *  THE LAYOUT IS THE SOLVER'S STATE, one plane per float: u faces, v faces,
 *  the layer thickness, cloud fraction, cloud times formation ascent, vapour,
 *  storm, noise phase A's displacement xyz and phase B's, then the low-passed
 *  ascent and the eye tracer, each plane layer-major, then row, then column;
 *  then the storm cells, eight floats a slot. The layout is told by its size:
 *  one without the last two planes restores them as zero. See
 *  FFlowSimulation::StateFloatsPerCell.
 *
 *  PITFALL: THE TRACERS ARE STATE TOO. The clouds, moisture and noise the deck
 *  draws are carried by the sim, not derived from the flow; a snapshot without
 *  them restores the winds under an empty sky, which reads as a fresh seed. */
UCLASS(BlueprintType)
class CLOUDATMOSPHERE_API UFlowSnapshot : public UDataAsset
{
	GENERATED_BODY()

public:
	/** Grid this was captured at, layers included. A restore onto a different
	 *  grid is refused rather than resampled. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Snapshot")
	FIntVector Grid = FIntVector::ZeroValue;

	/** Length Grid.X * Grid.Y * Grid.Z * FloatsPerCell + TrailingFloats, or the
	 *  same with LegacyFloatsPerCell. */
	UPROPERTY()
	TArray<float> State;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Snapshot")
	FFlowSnapshotProvenance Provenance;

	/** Simulated time and step count when captured, so a restored run continues
	 *  the forcing drift rather than snapping it back to zero. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Snapshot")
	float SimulatedTime = 0.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Snapshot")
	int32 StepsCompleted = 0;

	/** Floats per cell the current solver stores, and the layout without the
	 *  noise phases' w that still restores. Match FFlowSimulation's; duplicated
	 *  so this header stays free of the render-side one. */
	static constexpr int32 FloatsPerCell = 15;
	static constexpr int32 LegacyFloatsPerCell = 13;

	/** The storm cells after the planes. Matches
	 *  FFlowSimulation::StateTrailingFloats. */
	static constexpr int32 TrailingFloats = 8 * 32;

	bool IsValidFor(const FIntVector& InGrid) const
	{
		const int32 N = InGrid.X * InGrid.Y * InGrid.Z;

		return Grid == InGrid && N > 0
			&& (State.Num() == N * FloatsPerCell + TrailingFloats
				|| State.Num() == N * LegacyFloatsPerCell + TrailingFloats);
	}
};